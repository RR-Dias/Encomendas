module.exports = {
  content: ['./src-renderer/**/*.{html,js,jsx,ts,tsx}', './index.html'],
  theme: { extend: {} },
  plugins: [],
}
